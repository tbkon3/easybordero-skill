#!/usr/bin/env python3
"""
Setlist per il portale dei borderò: legge l'export del software DJ, pulisce i titoli,
divide i mashup, segnala doppioni e voci sospette, e alla fine scrive il CSV
da caricare sul portale.

Le regole vengono dalla piattaforma easybordero (utils/matching.py,
services/import_service.py, parsers/*), con alcune correzioni:
  - "feat"/"ft" si tolgono solo come parole intere ("Lift Me Up" resta tale);
  - "- Original Mix", "- Club Mix", "(Rmx)", "(Dub)", diciture YouTube e
    tonalità Camelot in testa vengono tolti;
  - "!" e "$" restano: fanno parte di titoli e nomi veri (FE!N, A$AP Ferg).

Comandi:
  python setlist.py prepara <file_export>      -> bozza.tsv, una riga per opera
  python setlist.py autori bozza.tsv           -> (facoltativo) autori e compositori da MusicBrainz
  python setlist.py rete                       -> MusicBrainz è raggiungibile da qui?
  python setlist.py storico bozza.tsv --memoria <file>  -> salva le decisioni per le serate dopo
  python setlist.py csv bozza.tsv --out setlist.csv [--durata-effettiva]

Solo libreria standard; per i file .xlsx serve openpyxl. "autori" ha bisogno
di poter raggiungere musicbrainz.org: se non può, lo dice e non tocca la bozza.
"""
import argparse
import csv
import io
import json
import os
import platform
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

# ---------------------------------------------------------------------------
# Pulizia del titolo
# ---------------------------------------------------------------------------

# Parole che, dentro una parentesi, indicano una versione e non il titolo.
_VERSION_WORDS = (
    r"REMIX|RMX|REMASH|REMODE|REDRUM|ULTIMIX|"
    r"EDIT|MIX|VERSION|VIP|EXTENDED|EXT\b|RADIO|LIVE\b|"
    r"ACOUSTIC|REMASTER|REPRISE|"
    r"BOOTLEG|REGGAEBOOT|BOOT\b|MASH|"
    r"FLIP|REWORK|RECUT|CUT\b|CUT UP|DEMO\b|"
    r"TRANSITION|TRANS\b|PARTYBREAK|BREAK\b|"
    r"INTRO|OUTRO|BLEND|"
    r"ACAPELLA|A CAPELLA|INSTRUMENTAL|INST\b|DUB\b|"
    r"TOOL\b|QUICK HIT|QUICKHIT|CLEAN\b|DIRTY\b|ORIGINAL|HYPE\b|"
    r"OFFICIAL|LYRIC|VISUALIZER|VIDEO\b|AUDIO\b|FREE DOWNLOAD|FREE DL"
)
REMIX_PATTERN = re.compile(
    r"\s*[\(\[][^\)\]]*?(?:" + _VERSION_WORDS + r")[^\)\]]*[\)\]]", re.IGNORECASE
)
DASH_VERSION_PATTERN = re.compile(
    r"\s+[-–]\s*(?:REMIX|RMX|REMASH|REMODE|REDRUM|ULTIMIX|EDIT|MIX|VERSION|VIP|"
    r"EXTENDED|RADIO|LIVE\b|ACOUSTIC|REMASTER|HYPE\b|ORIGINAL|CLUB|DUB\b|"
    r"INSTRUMENTAL|ACAPELLA|INTRO|OUTRO|SHORT|"
    r"BOOTLEG|REGGAEBOOT|BOOT\b|PARTYBREAK|BREAK\b).*$",
    re.IGNORECASE,
)
# Solo parole intere: "Lift Me Up", "Daft Punk Is Playing" restano intatti.
FEAT_PATTERN = re.compile(
    r"\s*[\(\[]?\b(?:FEAT|FT|FEATURING|PROD)\b\.?\s+[^\)\]]*[\)\]]?", re.IGNORECASE
)
# Numero di traccia in testa, solo se seguito da punto, trattino o parentesi
# ("01. Mayores", "01 - Mayores"): "99 Luftballons" resta com'è.
TRACK_NUMBER_PATTERN = re.compile(r"^\d{1,2}\s*[.\-)]\s+")
# Tonalità Camelot o BPM in testa: "8A - ", "11B - 124 - ", "128 - ".
KEY_PREFIX_PATTERN = re.compile(
    r"^\s*(?:(?:[1-9]|1[0-2])[ABab]|\d{2,3})\s*[-–]\s*(?:\d{2,3}\s*[-–]\s*)?"
)
TRAILING_BPM_PATTERN = re.compile(
    r"\s*\d{2,3}\s*BPM\s*(?:\(\d+\))?\s*$|\s+\d{3}\s*(?:\(\d+\))?\s*$", re.IGNORECASE
)
COPY_NUMBER_PATTERN = re.compile(r"\s*\(\d{1,2}\)\s*$")
# Versione scritta in coda senza parentesi né trattino: "P Secondiglian Extended".
TRAILING_VERSION_PATTERN = re.compile(
    r"\s+(?:EXTENDED(?:\s+MIX)?|ORIGINAL\s+MIX|CLUB\s+MIX|RADIO\s+EDIT|DJ\s+VERSION|"
    r"(?:ITALIAN|SPANISH|ENGLISH)\s+(?:MIX|VERSION|EDIT))\s*$",
    re.IGNORECASE,
)
SQUARE_BRACKETS_PATTERN = re.compile(r"\s*\[.*?\]")
CURLY_BRACKETS_PATTERN = re.compile(r"\s*\{.*?\}")
SPECIAL_CHARS_PATTERN = re.compile(r"[`~@#%^*_+=<>|\\]")
TRAILING_PARENS_PATTERN = re.compile(r"\s*\([^)]{3,}\)\s*$")
AGGRESSIVE_TRAILING_BRACKET_PATTERN = re.compile(
    r"\s*[\(\[][^\(\)\[\]]*[\)\]]?[\s.,;:!?'\"-]*$"
)
_BRACKET_RE = re.compile(r"[\(\[][^\)\]]*[\)\]]")


def clean_title(title: str) -> str:
    """Titolo ripulito per la ricerca, nelle maiuscole originali."""
    r = (title or "").strip()
    r = KEY_PREFIX_PATTERN.sub("", r)
    r = TRACK_NUMBER_PATTERN.sub("", r)
    r = SQUARE_BRACKETS_PATTERN.sub("", r)
    r = CURLY_BRACKETS_PATTERN.sub("", r)
    r = REMIX_PATTERN.sub("", r)
    r = FEAT_PATTERN.sub("", r)
    r = DASH_VERSION_PATTERN.sub("", r)
    r = TRAILING_VERSION_PATTERN.sub("", r)
    r = TRAILING_BPM_PATTERN.sub("", r)
    r = COPY_NUMBER_PATTERN.sub("", r)
    r = re.sub(r"[\s\-–—]+$", "", r)
    r = SPECIAL_CHARS_PATTERN.sub(" ", r)
    return re.sub(r"\s{2,}", " ", r).strip()


def clean_mashup_part(part: str) -> str:
    r = clean_title(part)
    for _ in range(2):
        r = TRAILING_PARENS_PATTERN.sub("", r).strip()
    return r


def strip_trailing_bracket_aggressive(title: str) -> str:
    """Ultimo tentativo: toglie qualsiasi parentesi finale, anche non chiusa."""
    result = title.strip()
    for _ in range(5):
        stripped = AGGRESSIVE_TRAILING_BRACKET_PATTERN.sub("", result).strip()
        if stripped == result:
            break
        result = stripped
    if not result or len(result) < 3 or result.upper() == title.strip().upper():
        return ""
    return result


def removed_brackets(title: str) -> list[str]:
    """Parentesi tolte dalla pulizia: servono come nota (remixer, versione)."""
    kept = clean_title(title)
    return [b for b in _BRACKET_RE.findall(title or "") if b not in kept]


def split_mashup_title(title: str) -> list[str]:
    """Divide su ' vs ', ' vs. ', ' X ' (maiuscola) fuori dalle parentesi."""
    depth = 0
    cuts: list[tuple[int, int]] = []
    i = 0
    while i < len(title):
        c = title[i]
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        elif depth == 0 and c == " ":
            if title[i:i + 5].lower() == " vs. ":
                cuts.append((i, 5)); i += 5; continue
            if title[i:i + 4].upper() == " VS ":
                cuts.append((i, 4)); i += 4; continue
            if title[i:i + 3] == " X ":
                cuts.append((i, 3)); i += 3; continue
        i += 1
    if not cuts:
        return [title]
    parts, prev = [], 0
    for pos, length in cuts:
        parts.append(title[prev:pos].strip())
        prev = pos + length
    parts.append(title[prev:].strip())
    return [p for p in parts if p]


MULTI_ARTIST_SPLIT_PATTERN = re.compile(
    r"\s*(?:,\s*|\s+&\s+|\s+AND\s+|\s+[Xx]\s+|\s+VS\.?\s+|\s+feat\.?\s+|\s+ft\.?\s+|\s+featuring\s+)",
    re.IGNORECASE,
)


def split_multi_artist(artist: str) -> list[str]:
    if not artist:
        return []
    seen, out = set(), []
    for p in MULTI_ARTIST_SPLIT_PATTERN.split(artist.strip()):
        p = p.strip()
        if p and p.upper() not in seen:
            seen.add(p.upper())
            out.append(p)
    return out


# ---------------------------------------------------------------------------
# Lettura dei formati
# ---------------------------------------------------------------------------

TITLE_COLS = {"track title", "titolo traccia", "titolo brano", "title", "titolo",
              "nome brano", "song title", "name", "song", "track", "nome"}
ARTIST_COLS = {"artist", "artista", "performer"}
TIME_COLS = {"time", "durata", "duration", "tempo", "length", "lunghezza", "playtime"}
AUTORE_COLS = {"autore", "author", "autori"}
COMPOSITORE_COLS = {"compositore", "composer", "compositori"}
_HEADER_TOKENS = TITLE_COLS | ARTIST_COLS | TIME_COLS | AUTORE_COLS | COMPOSITORE_COLS | {
    "bpm", "key", "tonalità", "tonalita", "genre", "genere", "#", "classifica", "rating",
    "start time", "end time", "deck", "notes"}


def _decode(data: bytes) -> str:
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", errors="replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def _duration_seconds(value) -> int | None:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    if re.fullmatch(r"\d+(\.\d+)?", s):
        n = float(s)
        return int(n / 1000) if n > 36000 else int(n)  # millisecondi in alcuni export
    parts = s.split(":")
    if all(re.fullmatch(r"\d+(\.\d+)?", p) for p in parts) and 2 <= len(parts) <= 3:
        nums = [float(p) for p in parts]
        if len(nums) == 2:
            return int(nums[0] * 60 + nums[1])
        return int(nums[0] * 3600 + nums[1] * 60 + nums[2])
    return None


def _row(title, artist="", duration=None, autore="", compositore="") -> dict:
    return {"titolo": (title or "").strip(), "artista": (artist or "").strip(),
            "durata_sec": _duration_seconds(duration),
            "autore_file": (autore or "").strip(), "compositore_file": (compositore or "").strip()}


def _from_table(rows: list[list[str]], solo_con: str = "") -> list[dict]:
    """Tabella con intestazione (TXT Rekordbox, CSV Serato, CSV/TSV generici, Excel)."""
    rows = [r for r in rows if any((c or "").strip() for c in r)]
    if not rows:
        return []
    head = [(c or "").strip().lower() for c in rows[0]]
    has_header = sum(1 for c in head if c in _HEADER_TOKENS) >= 2

    def find(cols):
        return next((i for i, h in enumerate(head) if h in cols), None) if has_header else None

    ti, ai, di = find(TITLE_COLS), find(ARTIST_COLS), find(TIME_COLS)
    au, co = find(AUTORE_COLS), find(COMPOSITORE_COLS)
    body = rows[1:] if has_header else rows
    if solo_con:  # il DJ ha indicato la colonna che dice quali righe prendere
        if solo_con.strip().lower() not in head:
            sys.exit(f"Nel file non c'è la colonna «{solo_con}». Le colonne sono: {', '.join(c for c in head if c)}")
        col = head.index(solo_con.strip().lower())
        body = [r for r in body if col < len(r) and (r[col] or "").strip()]
    serato = has_header and "start time" in head
    if serato and body:
        # Nella History di Serato la prima riga è la sessione, non un brano: ha la data.
        inizio = head.index("start time")
        ora = body[0][inizio] if inizio < len(body[0]) else ""
        artista = body[0][ai].strip() if ai is not None and ai < len(body[0]) else ""
        if re.search(r"\d{4}|,", ora) and not artista:
            body = body[1:]
    if ti is None:
        # Senza intestazione riconosciuta: prima colonna non numerica = titolo.
        sample = body[0] if body else []
        ti = next((i for i, c in enumerate(sample) if c and not c.strip().isdigit()), 0)
        if ai is None and len(sample) > ti + 1:
            ai = ti + 1
    out = []
    for r in body:
        cell = lambda i: (r[i] if i is not None and i < len(r) else "") or ""
        if cell(ti).strip():
            titolo, artista = cell(ti), cell(ai)
            if serato and ai is None and " - " in titolo:  # colonna unica "Artista - Titolo"
                artista, titolo = titolo.split(" - ", 1)
            out.append(_row(titolo, artista, cell(di), cell(au), cell(co)))
    return out


def _sniff_delimiter(text: str) -> str:
    first = text.split("\n", 1)[0]
    counts = {d: first.count(d) for d in ("\t", ";", ",")}
    return max(counts, key=counts.get) if max(counts.values()) else "\t"


def parse_delimited(text: str, solo_con: str = "") -> list[dict]:
    reader = csv.reader(io.StringIO(text), delimiter=_sniff_delimiter(text))
    return _from_table([list(r) for r in reader], solo_con)


def parse_xls(path: Path, solo_con: str = "") -> list[dict]:
    """Excel vecchio formato (.xls). Numeri interi e orari tornano come si leggono nel foglio."""
    try:
        import xlrd
    except ImportError:
        sys.exit("Per i file .xls serve xlrd: pip install xlrd. In alternativa salva il file come .xlsx o .csv.")
    try:
        wb = xlrd.open_workbook(str(path))
    except Exception:  # noqa: BLE001
        sys.exit("Non riesco ad aprire questo file .xls: salvalo come .xlsx o .csv e riprova.")
    ws = wb.sheet_by_index(0)

    def valore(c):
        if c.ctype == xlrd.XL_CELL_DATE:
            _, _, _, ore, minuti, secondi = xlrd.xldate_as_tuple(c.value, wb.datemode)
            return f"{ore}:{minuti:02d}:{secondi:02d}"
        if c.ctype == xlrd.XL_CELL_NUMBER and float(c.value).is_integer():
            return str(int(c.value))
        return "" if c.value is None else str(c.value)

    return _from_table([[valore(c) for c in ws.row(i)] for i in range(ws.nrows)], solo_con)


def looks_like_serato_txt(text: str) -> bool:
    prima = text.split("\n", 1)[0]
    return bool(re.match(r"\s*(name|artist)\s{2,}", prima, re.I)) and "start time" in prima.lower()


def parse_serato_txt(text: str) -> list[dict]:
    """Export TXT della History: colonne a larghezza fissa, divise da righe di trattini."""
    righe = [l for l in text.splitlines() if l.strip() and set(l.strip()) != {"-"}]
    inizi = [m.start() for m in re.finditer(r"\S+(?: \S+)*", righe[0])]
    return _from_table([[l[a:b].strip() for a, b in zip(inizi, inizi[1:] + [None])] for l in righe])


SERATO_ALTRO = ("Questo file di Serato non è un elenco di brani della serata (è una sessione o la libreria). "
                "Serve l'export della serata: in Serato apri History, scegli la serata, Export, formato CSV. "
                "In alternativa va bene il file .crate della serata.")
_CARTELLA_MIX = re.compile(r"\bmix(ati)?\b", re.IGNORECASE)


def _serato_blocchi(data: bytes):
    i = 0
    while i + 8 <= len(data):
        n = int.from_bytes(data[i + 4:i + 8], "big")
        if i + 8 + n > len(data):
            sys.exit("Il file .crate è incompleto o danneggiato: copialo di nuovo da Serato e riprova.")
        yield data[i:i + 4], data[i + 8:i + 8 + n]
        i += 8 + n


def parse_serato_crate(data: bytes) -> list[dict]:
    """File .crate: per ogni brano c'è solo il percorso del file, niente tag né durata."""
    blocchi = _serato_blocchi(data)
    tag, valore = next(blocchi, (b"", b""))
    if tag != b"vrsn" or b"C\x00r\x00a\x00t\x00e" not in valore:  # "Crate" in UTF-16 BE, a byte pari
        sys.exit(SERATO_ALTRO)
    out = []
    for tag, valore in blocchi:
        if tag != b"otrk":
            continue
        for itag, ivalore in _serato_blocchi(valore):
            if itag != b"ptrk":
                continue
            percorso = ivalore.decode("utf-16-be", errors="replace").rstrip("\x00")
            titolo, artista = title_artist_from_path(percorso)
            if titolo:
                r = _row(titolo, artista)
                cartelle = percorso.replace("\\", "/").split("/")
                if len(cartelle) > 1 and _CARTELLA_MIX.search(cartelle[-2]):
                    r["nota"] = f"nella cartella {cartelle[-2]}: DJ mix intero?"
                out.append(r)
    if not out:
        sys.exit("Questo crate non contiene brani (può essere una smart crate). "
                 "Serve l'export della serata: in Serato apri History, scegli la serata, Export, formato CSV.")
    return out


def parse_xlsx(path: Path, solo_con: str = "") -> list[dict]:
    try:
        import openpyxl
    except ImportError:
        sys.exit("Per i file Excel serve openpyxl: pip install openpyxl")
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = [["" if v is None else str(v) for v in r] for r in ws.iter_rows(values_only=True)]
    return _from_table(rows, solo_con)


def parse_traktor(text: str) -> list[dict]:
    root = ET.fromstring(text.encode("utf-8"))
    entries = root.findall(".//HISTORY/ENTRY") or root.findall(".//PLAYLISTS//ENTRY") \
        or root.findall(".//COLLECTION/ENTRY")
    out = []
    for e in entries:
        if not e.get("TITLE"):
            continue
        info = e.find("INFO")
        out.append(_row(e.get("TITLE"), e.get("ARTIST", ""),
                        info.get("PLAYTIME") if info is not None else None))
    return out


def parse_virtualdj(text: str) -> list[dict]:
    root = ET.fromstring(text.encode("utf-8"))
    out = []
    for s in root.iter("Song"):
        tags = s.find("Tags")
        title = s.get("Title") or (tags.get("Title") if tags is not None else "") or ""
        artist = s.get("Artist") or (tags.get("Artist") if tags is not None else "") or ""
        infos = s.find("Infos")
        dur = infos.get("SongLength") if infos is not None else None
        if not title and s.get("FilePath"):
            title, artist = title_artist_from_path(s.get("FilePath"))
        if title:
            out.append(_row(title, artist, dur))
    return out


def title_artist_from_path(path: str) -> tuple[str, str]:
    name = path.replace("\\", "/").split("/")[-1]
    name = name.rsplit(".", 1)[0] if "." in name else name
    m = re.match(r"^\d{4,}_(.+)$", name)
    if m:
        return m.group(1).replace("_", " ").strip(), ""
    name = re.sub(r"^\d+-\d{2}\s+", "", name)
    name = re.sub(r"^\d{1,2}[.\s]+", "", name)
    name = re.sub(r"^\d{2,}\.\s+", "", name)
    name = re.sub(r"^(\S+)-\s", r"\1 - ", name)
    name = re.sub(r"\s[–—]\s", " - ", name.replace("_", " ")).strip()
    if " - " in name:
        artist, title = name.split(" - ", 1)
        return title.strip(), artist.strip()
    return name, ""


def parse_m3u(text: str) -> list[dict]:
    lines = text.splitlines()
    # Ordine "Artista - Titolo" (default) o "Titolo - Artista" (iTunes):
    # vince chi compare prima nel percorso del file che segue.
    votes = {"at": 0, "ta": 0}
    for i, line in enumerate(lines[:-1]):
        if line.startswith("#EXTINF:") and "," in line and " - " in line:
            a, b = [x.strip().lower() for x in line.split(",", 1)[1].split(" - ", 1)]
            p = lines[i + 1].replace("\\", "/").lower()
            pa, pb = p.find(a), p.find(b)
            if pa >= 0 and (pb < 0 or pa < pb):
                votes["at"] += 1
            elif pb >= 0:
                votes["ta"] += 1
    title_first = sum(votes.values()) >= 3 and votes["ta"] / sum(votes.values()) >= 0.7
    out, i = [], 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("#EXTINF:"):
            meta = line[8:].split(",", 1)
            info = meta[1].strip() if len(meta) > 1 else ""
            if " - " in info:
                x, y = [s.strip() for s in info.split(" - ", 1)]
                title, artist = (x, y) if title_first else (y, x)
            else:
                title, artist = info, ""
            if title:
                out.append(_row(title, artist, meta[0] if meta[0].strip() not in ("-1", "0") else None))
            i += 2 if i + 1 < len(lines) and not lines[i + 1].startswith("#") else 1
            continue
        if line and not line.startswith("#"):
            title, artist = title_artist_from_path(line)
            if title:
                out.append(_row(title, artist))
        i += 1
    return out


# WinLive PRO: "ora<TAB> - autori<TAB>...<TAB>ARTISTA - TITOLO"
_WL_HEADER = re.compile(r"^\s*-+\s*[A-Z]+ LIST\s*\(Date\)", re.IGNORECASE)
_WL_TIME = re.compile(r"\d{1,2}:\d{2}:\d{2}")


def looks_like_winlive(text: str) -> bool:
    lines = [l for l in text.splitlines() if l.strip()][:20]
    if lines and _WL_HEADER.match(lines[0]):
        return True
    ok = sum(1 for l in lines if _WL_TIME.fullmatch(l.split("\t", 1)[0].strip()) and "\t" in l)
    return bool(lines) and ok >= max(1, len(lines) - len(lines) // 5)


def parse_winlive(text: str) -> list[dict]:
    out = []
    for line in text.splitlines():
        if not line.strip() or _WL_HEADER.match(line):
            continue
        fields = [f.strip() for f in line.split("\t")]
        if len(fields) < 3 or not _WL_TIME.fullmatch(fields[0]):
            continue
        authors_field = fields[1].lstrip("-–— ").strip()
        song = next((f for f in fields[2:] if f), "")
        if not song:
            continue
        song = re.sub(r"\s*[\(\[]\s*(?:CORI|CORO|BASE|MIDI|(?:VIDEO\s*)?KARAOKE)\s*[\)\]]", "",
                      song, flags=re.IGNORECASE)
        parts = [p.strip() for p in re.split(r"(?<!\s)\s+[-–—]\s+", song) if p.strip()]
        title = parts[-1] if parts else song
        artist = " & ".join(parts[:-1])
        if not re.search(r"[a-z]", title):
            title = re.sub(r"(?<=\s)X(?=\s)", "x", title)  # "ROTTA X CASA": X = per
        authors, performers = [], []
        if not re.match(r"^no auth\.?$", authors_field, re.IGNORECASE):
            for n in re.split(r"\s+[-–—]\s+", authors_field):
                n = re.sub(r"\b([^\W\d_])\.(?=[^\W\d_])", r"\1. ", n.strip())
                if n:
                    (performers if "*" in n else authors).append(n.replace("*", "").strip())
        if not artist and performers:
            artist = performers[0]
        out.append(_row(title, artist, None, authors[0] if authors else "",
                        authors[1] if len(authors) > 1 else ""))
    return out


def read_export(path: Path, solo_con: str = "") -> tuple[str, list[dict]]:
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        return "excel", parse_xlsx(path, solo_con)
    data = path.read_bytes()
    if ext == ".xls" and data[:4] == b"\xd0\xcf\x11\xe0":
        return "excel", parse_xls(path, solo_con)
    if ext == ".crate" or data[:4] == b"vrsn":
        return "serato crate", parse_serato_crate(data)
    if data[:16] == b"SQLite format 3\x00":
        sys.exit(SERATO_ALTRO)
    text = _decode(data)
    if "\x00" in text:
        sys.exit("Questo file non è testo leggibile, quindi non posso ricavarne i brani. "
                 "Serve l'export della serata in CSV, TXT, M3U, XML o Excel .xlsx.")
    if ext == ".nml":
        return "traktor", parse_traktor(text)
    if ext == ".xml":
        return "virtualdj", parse_virtualdj(text)
    if ext in (".m3u", ".m3u8") or text.lstrip().startswith("#EXTM3U"):
        return "m3u", parse_m3u(text)
    if looks_like_winlive(text):
        return "winlive", parse_winlive(text)
    if looks_like_serato_txt(text):
        return "serato txt", parse_serato_txt(text)
    return "tabella", parse_delimited(text, solo_con)


# ---------------------------------------------------------------------------
# Bozza: una riga per opera, già pulita, da correggere solo dove serve
# ---------------------------------------------------------------------------

_MASHUP_HINT = re.compile(r"mash|medley|\bvs\b", re.IGNORECASE)
_NOT_MUSIC_HINT = re.compile(
    r"\b(jingle|sigla|spot|promo|sound ?fx|sfx|effetto|effetti|test|"
    r"unknown|untitled|track\s*\d+|id)\b", re.IGNORECASE)
LONG_MIX_SECONDS = 15 * 60
# L'interprete principale: tutto ciò che viene prima di feat, virgola, x o vs.
# "&" resta, perché spesso è un duo ("Milk & Sugar", "Zion & Lennox").
_MAIN_ARTIST_SPLIT = re.compile(
    r"\s*(?:,|\s(?:feat\.?|ft\.?|featuring|x|vs\.?)\s)", re.IGNORECASE)

BOZZA_COLS = ["n", "titolo", "performer", "autore", "compositore", "durata", "controlla"]


def _mmss(sec):
    return f"{sec // 60}:{sec % 60:02d}" if sec else ""


def voci_memoria(memoria: dict | None, titolo: str, artista: str) -> list[dict] | None:
    """Dati già trovati per questo brano. Senza artista basta il titolo, se nello storico ce n'è uno solo."""
    if not memoria:
        return None
    chiave = chiave_storico(titolo, artista)
    if chiave in memoria:
        return memoria[chiave]
    if chiave[1]:
        return None
    simili = [v for k, v in memoria.items() if k[0] == chiave[0] and v[0]["stato"] == "ok"]
    return simili[0] if len(simili) == 1 else None


def prepara(path: Path, memoria: dict | None = None) -> tuple[list[dict], dict]:
    fmt, rows = read_export(path)
    bozza, seen, by_title, gia_storico = [], set(), {}, set()
    info = {"file": path.name, "formato": fmt, "righe": len(rows), "doppioni": [], "mashup": 0,
            "storico": 0, "storico_tolti": [], "origine": []}
    for n, r in enumerate(rows, start=1):
        raw_t, raw_a = r["titolo"], r["artista"]
        if not raw_a and re.search(r"\.(mp3|wav|aiff?|flac|m4a)$", raw_t, re.I):
            raw_t, raw_a = title_artist_from_path(raw_t)
        chiave = chiave_storico(raw_t, raw_a)
        voci = voci_memoria(memoria, raw_t, raw_a)
        if voci:
            if chiave in gia_storico:
                info["doppioni"].append(f"riga {n} {raw_t}")
                continue
            gia_storico.add(chiave)
            if voci[0]["stato"] == "tolto":
                info["storico_tolti"].append(raw_t)
                continue
            info["storico"] += 1
            info["origine"].append({"riga": n, "titolo_file": raw_t, "artista_file": raw_a, "parti": len(voci)})
            for k, v in enumerate(voci, start=1):
                by_title.setdefault(v["titolo"].upper(), n)
                bozza.append({
                    "n": f"{n}" if len(voci) == 1 else f"{n}.{k}",
                    "titolo": v["titolo"], "performer": v["performer"],
                    "autore": v["autore"], "compositore": v["compositore"],
                    "durata": _mmss(r["durata_sec"]),
                    "controlla": STORICO_NOTA + (f" ({STORICO_AUTORI})" if v["autori_cercati"] == "si" else ""),
                })
            continue
        performer = _MAIN_ARTIST_SPLIT.split(raw_a.strip())[0].strip() if raw_a else ""
        note = [r["nota"]] if r.get("nota") else []
        if r["durata_sec"] and r["durata_sec"] > LONG_MIX_SECONDS:
            note.append(f"dura {_mmss(r['durata_sec'])}: DJ mix intero?")
        if _NOT_MUSIC_HINT.search(raw_t) and len(clean_title(raw_t)) < 25:
            note.append("forse non è un brano")
        prima = len(bozza)
        parts = split_mashup_title(raw_t)
        if len(parts) > 1:
            info["mashup"] += 1
            note.append(f"mashup diviso, artisti nel file: {raw_a}")
        elif _MASHUP_HINT.search(" ".join(removed_brackets(raw_t))) or re.search(r"\s(X|vs\.?|VS)\s", raw_a):
            note.append(f"forse mashup senza separatore: {raw_t} / {raw_a}")
        # Mashup: gli artisti del file nello stesso ordine delle parti
        # ("Kesha X Avicii" per "Tik Tok X Levels"); se non tornano, vuoto.
        part_artists = [performer] if len(parts) == 1 else []
        if len(parts) > 1:
            for splitter in (r"\s(?:X|x|vs\.?|VS|Vs)\s", r"\s*,\s*"):
                cand = [c for c in re.split(splitter, raw_a) if c.strip()]
                if len(cand) == len(parts):
                    part_artists = [_MAIN_ARTIST_SPLIT.split(c.strip())[0].strip() for c in cand]
                    break
        for k, part in enumerate(parts, start=1):
            titolo = (clean_mashup_part(part) if len(parts) > 1 else clean_title(part)) or part.strip()
            key = (titolo.upper(), raw_a.strip().upper())
            if key in seen:
                info["doppioni"].append(f"riga {n} {titolo}")
                continue
            seen.add(key)
            nota = list(note)
            if titolo.upper() in by_title:
                nota.append(f"stesso titolo della riga {by_title[titolo.upper()]}")
            by_title.setdefault(titolo.upper(), n)
            bozza.append({
                "n": f"{n}" if len(parts) == 1 else f"{n}.{k}",
                "titolo": titolo,
                "performer": part_artists[k - 1] if len(part_artists) >= k else "",
                "autore": r["autore_file"], "compositore": r["compositore_file"],
                "durata": _mmss(r["durata_sec"]),
                "controlla": "; ".join(nota),
            })
        if len(bozza) > prima:
            info["origine"].append({"riga": n, "titolo_file": raw_t, "artista_file": raw_a,
                                    "parti": len(bozza) - prima})
    return bozza, info


AGGIUNTIVI_NOTA = "aggiunto dal DJ: non togliere e non chiedere se è stato suonato"
_ESTENSIONI_AGGIUNTIVI = (".csv", ".tsv", ".txt", ".xlsx", ".xlsm", ".xls")


def _leggi_elenco(path: Path) -> list[dict] | None:
    """Elenco scritto a mano, una riga per brano. None se il file è una tabella."""
    testo = _decode(path.read_bytes())
    if "\x00" in testo or re.search(r"[\t;]", testo) or looks_like_winlive(testo) or looks_like_serato_txt(testo):
        return None
    return [_row(re.sub(r"\s[–—]\s", " - ", re.sub(r"^\s*(?:\d+[.)]\s*|[-*•]\s+)", "", riga)))
            for riga in testo.splitlines() if riga.strip()]


def aggiungi_brani(bozza: list[dict], path: Path, info: dict, memoria: dict | None = None, solo_con: str = "") -> None:
    """Porta nella bozza i brani del file indicato dal DJ, così come li ha scritti."""
    if not path.is_file():
        sys.exit(f"Non trovo il file dei brani da aggiungere: {path}")
    if path.suffix.lower() not in _ESTENSIONI_AGGIUNTIVI:
        sys.exit("Il file dei brani da aggiungere deve essere un Excel o un CSV.")
    righe = _leggi_elenco(path) if path.suffix.lower() == ".txt" and not solo_con else None
    if righe is None:
        righe = read_export(path, solo_con)[1]
    selezione = f" (solo le righe segnate nella colonna «{solo_con}»)" if solo_con else ""
    if righe and righe[0]["titolo"].lower() in TITLE_COLS and not righe[0]["artista"]:
        righe = righe[1:]  # file con la sola colonna del titolo
    if not righe:
        sys.exit(f"Nel file dei brani da aggiungere non ho trovato brani: {path.name}")
    aggiunti, gia_presenti, senza, visti = 0, 0, [], set()
    for r in righe:
        titolo, artista = r["titolo"], r["artista"]
        if not artista and not (r["autore_file"] or r["compositore_file"]) and " - " in titolo:
            artista, titolo = (x.strip() for x in titolo.split(" - ", 1))
        t, a = chiave_storico(titolo, artista)
        if (t, a) in visti:
            continue
        visti.add((t, a))
        nuova = {"titolo": titolo, "performer": artista, "autore": r["autore_file"],
                 "compositore": r["compositore_file"], "durata": _mmss(r["durata_sec"])}
        nota = AGGIUNTIVI_NOTA
        voci = voci_memoria(memoria, titolo, artista)
        if voci and len(voci) == 1 and voci[0]["stato"] == "ok":  # dati già trovati: non si cercano di nuovo
            for campo in ("performer", "autore", "compositore"):
                nuova[campo] = nuova[campo] or voci[0][campo]
            nota += "; " + STORICO_NOTA + (f" ({STORICO_AUTORI})" if voci[0]["autori_cercati"] == "si" else "")
            a = chiave_storico(titolo, nuova["performer"])[1]
        uguale = None
        for b in bozza:
            bt, ba = chiave_storico(b["titolo"], b["performer"])
            if bt == t and (not a or not ba or a in ba or ba in a):
                uguale = b
                break
        if uguale is not None:  # già nell'export: una riga sola, con i dati del DJ
            uguale.update({k: v for k, v in nuova.items() if v})
            uguale["controlla"] = "; ".join(x for x in (uguale["controlla"], nota) if x)
            gia_presenti += 1
            continue
        aggiunti += 1
        bozza.append(dict(nuova, n=f"A{aggiunti}", controlla=nota))
        info["origine"].append({"riga": f"A{aggiunti}", "titolo_file": titolo, "artista_file": artista, "parti": 1})
        if not (nuova["performer"] or nuova["autore"] or nuova["compositore"]):
            senza.append(titolo)
    info["aggiuntivi"] = {"file": path.name, "aggiunti": aggiunti, "gia_presenti": gia_presenti, "senza": senza,
                          "selezione": selezione}


def scrivi_bozza(bozza: list[dict], out: Path) -> None:
    with open(out, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=BOZZA_COLS, delimiter="\t", lineterminator="\n")
        w.writeheader()
        w.writerows(bozza)


# ---------------------------------------------------------------------------
# CSV per il portale dei borderò
# ---------------------------------------------------------------------------

HEADER = ["Titolo", "Autore", "Compositore", "Performer", "Durata"]


def scrivi_csv(bozza_path: Path, out: Path, durata_effettiva: bool, separatore: str) -> list[str]:
    with open(bozza_path, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    avvisi, unici, visti = [], [], set()
    clean = lambda s: re.sub(r"[\r\n\t]+", " ", (s or "")).strip()
    for r in rows:
        titolo = clean(r.get("titolo"))
        performer, autore, compositore = clean(r.get("performer")), clean(r.get("autore")), clean(r.get("compositore"))
        if not titolo or titolo.startswith("#"):
            continue
        if not (autore or compositore or performer):
            avvisi.append(f"riga {r.get('n')} {titolo}: manca l'interprete, saltata")
            continue
        k = (titolo.upper(), performer.upper())
        if k in visti:
            continue
        visti.add(k)
        unici.append([titolo.upper(), autore, compositore, performer,
                      clean(r.get("durata")) if durata_effettiva else ""])
    # utf-8-sig: senza la firma iniziale (BOM) Excel legge l'UTF-8 come
    # Windows-1252 e "Guè" diventa "GuÃ¨".
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=separatore, quoting=csv.QUOTE_MINIMAL, lineterminator="\r\n")
        w.writerow(HEADER)
        w.writerows(unici)
    return [f"Scritto {out} con {len(unici)} brani."] + avvisi


# ---------------------------------------------------------------------------
# Autori e compositori da MusicBrainz (facoltativo)
# ---------------------------------------------------------------------------

MB_API = "https://musicbrainz.org/ws/2/"
MB_UA = "easybordero-skill/1.1 ( https://github.com/tbkon3/easybordero-skill )"
MB_PAUSA = 1.1          # MusicBrainz accetta una richiesta al secondo
MB_VERSIONI = 4         # versioni del brano da guardare prima di arrendersi
MB_NOTA = "autori da MusicBrainz, da controllare"
MB_SECONDI_A_BRANO = 6  # media misurata 5,7 s su 495 brani di 5 serate vere (11/10/2026)
_mb_ultima = [0.0]


class MBNonRaggiungibile(Exception):
    """Nessuna strada verso musicbrainz.org (rete chiusa, proxy che rifiuta)."""


class MBNonRisponde(Exception):
    """MusicBrainz raggiunto ma lento o sovraccarico: vale la pena riprovare."""


def _mb_get(path: str, _timeout: int = 30, _tentativi: int = 3, **params) -> dict:
    params["fmt"] = "json"
    url = MB_API + path + "?" + urllib.parse.urlencode(params)
    motivo = ""
    for tentativo in range(_tentativi):
        attesa = MB_PAUSA - (time.time() - _mb_ultima[0])
        if attesa > 0:
            time.sleep(attesa)
        _mb_ultima[0] = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": MB_UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=_timeout) as r:
                # Il filtro di rete di ChatGPT risponde 200 con una pagina HTML.
                if "json" not in r.headers.get_content_type():
                    raise MBNonRaggiungibile(f"il sito è bloccato ({r.headers.get_content_type()})")
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return {}
            if e.code in (429, 500, 502, 503, 504):     # sovraccarico: aspetta e riprova
                motivo = f"HTTP {e.code}"
                time.sleep(3 + 3 * tentativo)
                continue
            raise MBNonRaggiungibile(f"HTTP {e.code}")
        except (TimeoutError, urllib.error.URLError, OSError) as e:
            reason = getattr(e, "reason", e)
            if isinstance(reason, TimeoutError) or isinstance(e, TimeoutError):
                motivo = "tempo scaduto"
                continue
            raise MBNonRaggiungibile(str(reason))
        except ValueError:                              # risposta non JSON
            motivo = "risposta illeggibile"
            time.sleep(3)
    raise MBNonRisponde(motivo)


def _mb_norm(s: str) -> str:
    return re.sub(r"[^0-9a-z]+", " ", unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore")
                  .decode().lower()).strip()


def _mb_lucene(s: str) -> str:
    return re.sub(r'([+\-&|!(){}\[\]^"~*?:\\/])', r"\\\1", s)


def mb_autori(titolo: str, performer: str) -> tuple[list[str], list[str]] | None:
    """(autori, compositori) dell'opera, oppure None se non trovata."""
    artista = split_multi_artist(performer)[0] if performer else ""
    if not titolo or not artista:
        return None
    q = f'recording:"{_mb_lucene(titolo)}" AND artist:"{_mb_lucene(artista)}"'
    t, a = _mb_norm(titolo), _mb_norm(artista)
    candidati = []
    for rec in _mb_get("recording", query=q, limit=15).get("recordings", []):
        rt = _mb_norm(rec.get("title"))
        crediti = _mb_norm(" ".join(c.get("name", "") for c in rec.get("artist-credit", [])))
        if int(rec.get("score", 0)) >= 90 and (rt == t or rt.startswith(t + " ")) and a in crediti:
            candidati.append(rec["id"])
    for rid in candidati[:MB_VERSIONI]:
        det = _mb_get("recording/" + rid, inc="work-rels work-level-rels artist-rels")
        for rel in det.get("relations", []):
            opera = rel.get("work")
            if rel.get("type") != "performance" or not opera:
                continue
            ruoli = {"lyricist": [], "composer": [], "writer": []}
            for ar in opera.get("relations", []):
                # MusicBrainz scrive "Boi‐1da" con il trattino tipografico U+2010.
                nome = re.sub("[‐‑]", "-", (ar.get("artist") or {}).get("name") or "")
                if ar.get("type") in ruoli and nome and nome not in ruoli[ar["type"]]:
                    ruoli[ar["type"]].append(nome)
            # "writer" non dice se testo o musica: va in entrambe le colonne.
            autori = ruoli["lyricist"] or ruoli["writer"]
            compositori = ruoli["composer"] or ruoli["writer"]
            if autori or compositori:
                return autori, compositori
    return None


def mb_stato() -> str:
    """Una sola richiesta di prova, per sapere prima se la ricerca degli autori è possibile."""
    try:
        _mb_get("recording", _timeout=10, _tentativi=1, query='recording:"Macarena"', limit=1)
        return "raggiungibile"
    except MBNonRaggiungibile as e:
        return f"NON RAGGIUNGIBILE ({e})"
    except MBNonRisponde as e:
        return f"raggiungibile ma lento in questo momento ({e})"


def stime(n_brani: int, n_cerca: int | None = None) -> tuple[int, int]:
    """Minuti stimati: (solo interpreti, ricerca autori in più)."""
    n_cerca = n_brani if n_cerca is None else n_cerca
    solo = max(2, round(1 + n_brani / 60))
    autori = max(1 if n_cerca else 0, round(n_cerca * MB_SECONDI_A_BRANO / 60))
    return solo, autori


def cerca_autori(bozza_path: Path, secondi: int) -> list[str]:
    """Riempie autore e compositore nella bozza. Riprende da dove si era fermato."""
    with open(bozza_path, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    fatti_path = bozza_path.with_name(bozza_path.stem + "_autori_cercati.txt")
    fatti = set(fatti_path.read_text(encoding="utf-8").splitlines()) if fatti_path.exists() else set()
    saltati_path = bozza_path.with_name(bozza_path.stem + "_autori_saltati.txt")
    non_risposti = set(saltati_path.read_text(encoding="utf-8").splitlines()) if saltati_path.exists() else set()
    chiave = lambda r: f"{r['titolo']}|{r.get('performer', '')}"
    da_fare = [r for r in rows
               if (r.get("titolo") or "").strip() and not (r.get("autore") or r.get("compositore"))
               and chiave(r) not in fatti and STORICO_AUTORI not in (r.get("controlla") or "")]
    inizio, trovati, cercati, saltati, di_fila = time.time(), 0, 0, 0, 0
    fermo = ""
    try:
        for r in da_fare:
            if time.time() - inizio > secondi:
                break
            try:
                esito = mb_autori(r["titolo"].strip(), (r.get("performer") or "").strip())
                di_fila = 0
            except MBNonRisponde as e:
                esito, saltati, di_fila = None, saltati + 1, di_fila + 1
                non_risposti.add(chiave(r))
                if di_fila >= 3:
                    cercati += 1
                    fatti.add(chiave(r))
                    fermo = f"MUSICBRAINZ NON RISPONDE ({e}): fermo. Riprova fra qualche minuto, oppure continua senza autori."
                    break
            cercati += 1
            fatti.add(chiave(r))
            if esito:
                trovati += 1
                r["autore"], r["compositore"] = " / ".join(esito[0]), " / ".join(esito[1])
                r["controlla"] = "; ".join(x for x in ((r.get("controlla") or ""), MB_NOTA) if x)
    except MBNonRaggiungibile as e:
        if not cercati:
            return [f"MUSICBRAINZ NON RAGGIUNGIBILE ({e}). Nessuna modifica alla bozza."]
        fermo = f"MUSICBRAINZ NON PIU' RAGGIUNGIBILE ({e}): fermo. Quello che ho trovato è salvato."
    finally:
        if cercati:
            scrivi_bozza(rows, bozza_path)
            fatti_path.write_text("\n".join(sorted(fatti)), encoding="utf-8")
            saltati_path.write_text("\n".join(sorted(non_risposti)), encoding="utf-8")
    out = [f"Cercati {cercati} brani, autori trovati per {trovati}"
           + (f", {saltati} saltati perché MusicBrainz non rispondeva" if saltati else "")
           + f". Bozza aggiornata: {bozza_path}"]
    restano = len(da_fare) - cercati
    if fermo:
        out.append(fermo)
    if restano:
        out.append(f"RESTANO {restano} brani: rilancia lo stesso comando per continuare.")
    else:
        con = sum(1 for r in rows if r.get("autore") or r.get("compositore"))
        out.append(f"FINITO: {con} brani su {len(rows)} hanno autori o compositori.")
    return out


# ---------------------------------------------------------------------------
# Storico: le decisioni delle serate passate (solo dove la cartella resta)
# ---------------------------------------------------------------------------

STORICO_NOTA = "confermato dallo storico"
STORICO_AUTORI = "autori già cercati"
STORICO_COLS = ["titolo_file", "artista_file", "parte", "titolo", "performer",
                "autore", "compositore", "stato", "autori_cercati"]
ORIGINE_COLS = ["riga", "titolo_file", "artista_file", "parti"]


def ambiente() -> str:
    """desktop, browser o sconosciuto. Vale solo come indizio: lo decide anche la cartella aperta dal DJ."""
    if platform.system() in ("Windows", "Darwin"):
        return "desktop"
    if os.getcwd().startswith("/workspace/scratch") or os.path.exists("/mnt/user-data") or os.path.exists("/mnt/data"):
        return "browser"
    return "sconosciuto"


def chiave_storico(titolo: str, artista: str) -> tuple[str, str]:
    norm = lambda x: re.sub(r"\s+", " ", (x or "")).strip().casefold()
    return norm(titolo), norm(artista)


def leggi_memoria(path: Path) -> dict:
    """{chiave: [voci]}. File assente = memoria vuota; file rovinato = ValueError, mai sovrascriverlo."""
    if not path.exists():
        return {}
    text = _decode(path.read_bytes()).lstrip("﻿")
    # Se il DJ lo riapre e salva con Excel italiano, il separatore diventa il punto e virgola.
    prima = text.split("\n", 1)[0]
    righe = list(csv.DictReader(io.StringIO(text), delimiter=";" if ";" in prima and "," not in prima else ","))
    if text.strip() and (not righe or any(c not in righe[0] for c in STORICO_COLS)):
        raise ValueError("colonne non riconosciute")
    memoria: dict = {}
    for r in righe:
        memoria.setdefault(chiave_storico(r["titolo_file"], r["artista_file"]), []).append(r)
    return memoria


def scrivi_memoria(memoria: dict, path: Path) -> None:
    """Scrive su un file temporaneo e poi lo sostituisce; la versione precedente resta in .bak."""
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=STORICO_COLS, lineterminator="\r\n")
        w.writeheader()
        for voci in memoria.values():
            w.writerows({c: v.get(c, "") for c in STORICO_COLS} for v in voci)
    if path.exists():
        os.replace(path, path.with_name(path.name + ".bak"))
    os.replace(tmp, path)


def _origine_path(bozza_path: Path) -> Path:
    return bozza_path.with_name(bozza_path.stem + "_origine.tsv")


def scrivi_origine(origine: list[dict], bozza_path: Path) -> None:
    with open(_origine_path(bozza_path), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=ORIGINE_COLS, delimiter="\t", lineterminator="\n")
        w.writeheader()
        w.writerows(origine)


def salva_storico(bozza_path: Path, memoria_path: Path, tolti: set[int],
                  dimentica: tuple[str, ...] = (), aggiuntivi: bool = False) -> list[str]:
    """Aggiorna la memoria con la bozza finale. Una riga mancante si salva come tolta solo se il DJ l'ha detto."""
    try:
        memoria = leggi_memoria(memoria_path)
    except ValueError as e:
        return [f"STORICO ILLEGGIBILE ({e}): non l'ho toccato."]
    if not _origine_path(bozza_path).exists():
        return ["STORICO NON SALVATO: manca il file di origine, rilancia prepara."]
    via = {chiave_storico(t, "")[0] for t in dimentica}
    prima = len(memoria)
    memoria = {k: v for k, v in memoria.items() if k[0] not in via}
    dimenticati = prima - len(memoria)
    leggi = lambda p: set(p.read_text(encoding="utf-8").splitlines()) if p.exists() else set()
    cercati = leggi(bozza_path.with_name(bozza_path.stem + "_autori_cercati.txt"))
    cercati -= leggi(bozza_path.with_name(bozza_path.stem + "_autori_saltati.txt"))
    with open(bozza_path, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    per_riga: dict = {}
    for r in rows:
        testa = str(r.get("n") or "").split(".")[0]
        if testa.isdigit():
            per_riga.setdefault(int(testa), []).append(r)
        elif re.fullmatch(r"A\d+", testa):
            per_riga.setdefault(testa, []).append(r)
    with open(_origine_path(bozza_path), encoding="utf-8", newline="") as f:
        origine = list(csv.DictReader(f, delimiter="\t"))
    pulito = lambda x: re.sub(r"[\r\n\t]+", " ", x or "").strip()
    nuovi = aggiornati = tolte = saltate = ricordati = 0
    for o in origine:
        riga = int(o["riga"]) if o["riga"].isdigit() else o["riga"]  # "A1": brano aggiunto dal DJ
        if isinstance(riga, str) and not aggiuntivi:
            continue
        ch = chiave_storico(o["titolo_file"], o["artista_file"])
        base = {"titolo_file": o["titolo_file"], "artista_file": o["artista_file"]}
        c_era = ch in memoria
        if riga in tolti:
            memoria[ch] = [dict(base, parte="1", titolo="", performer="", autore="", compositore="",
                                stato="tolto", autori_cercati="")]
            tolte += 1
            continue
        finali = per_riga.get(riga, [])
        # Riga cancellata o mashup rimasto con meno parti: spesso vale solo per quella
        # serata ("già suonata"), quindi non diventa una regola per le prossime.
        if len(finali) < int(o["parti"]) or any(
                not pulito(r.get("titolo")) or not (pulito(r.get("performer")) or pulito(r.get("autore"))
                                                    or pulito(r.get("compositore")))
                for r in finali):
            saltate += 1
            continue
        memoria[ch] = [dict(
            base, parte=str(k), titolo=pulito(r["titolo"]), performer=pulito(r.get("performer")),
            autore=pulito(r.get("autore")), compositore=pulito(r.get("compositore")), stato="ok",
            autori_cercati="si" if (r.get("autore") or r.get("compositore") or STORICO_AUTORI in (r.get("controlla") or "")
                                    or f"{r['titolo']}|{r.get('performer', '')}" in cercati) else "no",
        ) for k, r in enumerate(finali, start=1)]
        if isinstance(riga, str):
            ricordati += 1
            continue
        aggiornati += c_era
        nuovi += not c_era
    scrivi_memoria(memoria, memoria_path)
    return [f"STORICO SALVATO in {memoria_path}: {len(memoria)} brani in memoria "
            + (f"({ricordati} aggiunti dal DJ) " if aggiuntivi else "") +
            f"({nuovi} nuovi, {aggiornati} confermati o aggiornati, {tolte} da togliere, "
            f"{saltate} righe di questa serata non memorizzate, {dimenticati} dimenticati)."]


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("prepara", help="legge l'export e scrive la bozza")
    p1.add_argument("file")
    p1.add_argument("--out", default="bozza.tsv")
    p1.add_argument("--storico", help="memoria delle serate passate, se il DJ la vuole")
    p1.add_argument("--aggiuntivi", help="Excel, CSV o elenco con i brani che il DJ vuole aggiungere sempre")
    p1.add_argument("--solo-con", default="", help="colonna indicata dal DJ: entrano solo le righe dove è compilata")
    p2 = sub.add_parser("csv", help="scrive il CSV dalla bozza corretta")
    p2.add_argument("bozza")
    p2.add_argument("--out", default="setlist.csv")
    p2.add_argument("--durata-effettiva", action="store_true")
    p2.add_argument("--separatore", default=",", choices=[",", ";"])
    p3 = sub.add_parser("autori", help="cerca autori e compositori su MusicBrainz")
    p3.add_argument("bozza")
    p3.add_argument("--secondi", type=int, default=240, help="tempo massimo per volta")
    sub.add_parser("rete", help="controlla se MusicBrainz è raggiungibile")
    p4 = sub.add_parser("storico", help="salva le decisioni della bozza finale")
    p4.add_argument("bozza")
    p4.add_argument("--memoria", required=True)
    p4.add_argument("--aggiuntivi", action="store_true", help="ricorda anche i brani aggiunti dal DJ")
    p4.add_argument("--tolti", default="", help="righe (colonna n) che il DJ ha chiesto di togliere: 12,35")
    p4.add_argument("--dimentica", action="append", default=[], help="titolo com'è nel file da togliere dalla memoria")
    a = ap.parse_args()
    if a.cmd == "rete":
        print(f"MusicBrainz: {mb_stato()}.")
    elif a.cmd == "autori":
        for line in cerca_autori(Path(a.bozza), a.secondi):
            print(line)
    elif a.cmd == "storico":
        tolti = {int(x.split(".")[0]) for x in a.tolti.replace(" ", "").split(",") if x}
        for line in salva_storico(Path(a.bozza), Path(a.memoria), tolti, tuple(a.dimentica), a.aggiuntivi):
            print(line)
    elif a.cmd == "prepara":
        memoria = None
        if a.storico:
            try:
                memoria = leggi_memoria(Path(a.storico))
            except ValueError as e:
                print(f"STORICO ILLEGGIBILE ({e}): per questa serata lo ignoro.")
        bozza, info = prepara(Path(a.file), memoria)
        if a.aggiuntivi:
            aggiungi_brani(bozza, Path(a.aggiuntivi), info, memoria, a.solo_con)
        # Nuova bozza, nuova serata: le ricerche fatte per la bozza precedente non valgono più.
        for coda in ("_autori_cercati.txt", "_autori_saltati.txt"):
            Path(a.out).with_name(Path(a.out).stem + coda).unlink(missing_ok=True)
        scrivi_bozza(bozza, Path(a.out))
        scrivi_origine(info["origine"], Path(a.out))
        print(f"{info['file']} ({info['formato']}): {info['righe']} righe, {len(bozza)} opere in bozza, "
              f"{info['mashup']} mashup divisi, {len(info['doppioni'])} doppioni tolti.")
        if a.aggiuntivi:
            x = info["aggiuntivi"]
            print(f"AGGIUNTIVI: {x['aggiunti']} brani aggiunti da {x['file']}{x['selezione']}, "
                  f"{x['gia_presenti']} erano già nell'export (una riga sola, con i dati del DJ).")
            if x["senza"]:
                print(f"AGGIUNTIVI SENZA INTERPRETE: {'; '.join(x['senza'])}")
        print(f"AMBIENTE: {ambiente()}.")
        if memoria is not None:
            print(f"STORICO: {len(memoria)} brani in memoria, {info['storico']} righe confermate in automatico, "
                  f"{len(info['storico_tolti'])} tolte come deciso in passato"
                  + (f" ({'; '.join(info['storico_tolti'])})" if info["storico_tolti"] else "") + ".")
        nuovi = [r for r in bozza if STORICO_NOTA not in r["controlla"]]
        da_cercare = [r for r in bozza if not (r["autore"] or r["compositore"]) and STORICO_AUTORI not in r["controlla"]]
        solo, autori = stime(len(nuovi), len(da_cercare))
        print(f"STIMA solo interpreti: circa {solo} minuti.")
        print(f"STIMA anche autori e compositori: circa {solo + autori} minuti in tutto "
              f"({autori} per la ricerca su MusicBrainz, servizio esterno).")
        print(f"MusicBrainz: {mb_stato()}.")
        print(f"Bozza: {a.out}\n")
        print(Path(a.out).read_text(encoding="utf-8"))
    else:
        for line in scrivi_csv(Path(a.bozza), Path(a.out), a.durata_effettiva, a.separatore):
            print(line)


if __name__ == "__main__":
    main()
